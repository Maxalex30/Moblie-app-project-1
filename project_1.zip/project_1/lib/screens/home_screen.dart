import 'package:flutter/material.dart';
// i would like for all the buttons to be better organisifnd , looka t other mendation apps for exmple, mabey a banner maybe a single hover int he center that neds yo to move the mouse over ton e of the buttons, it could be ironi c liek a welcome screen that needs a one schmillion dollar sub t o get started on stress reduction a loadign bar after wards saying see , im less stressed now. 
// need to make sure i have everythign from the proposal
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mindfulness App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/mindfulness');
              },
              child: Text('Mindfulness Exercises'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/stress-reduction');
              },
              child: Text('Stress Reduction Techniques'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/daily-affirmations');
              },
              child: Text('Daily Affirmations'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/mood-tracking');
              },
              child: Text('Mood Tracking'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/settings');
              },
              child: Text('Settings'),
            ),
          ],
        ),
      ),
    );
  }
}
