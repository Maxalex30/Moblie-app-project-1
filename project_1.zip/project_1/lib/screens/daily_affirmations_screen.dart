import 'package:flutter/material.dart';

class DailyAffirmationsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daily Affirmations'),
      ),
      body: Center(
        child: Text('Daily Affirmations will be displayed here'),
        // I want for there to be an option between 20 randomized affriations that will fade intot he screenin text like white to balck ( if I could in the future i would like to amke it so that there could eb a way to have infite options theough using chatgpt or ai to randomly genrate a new affrimation every time. and maybe something like a zodiac dispaly that will randomly gentate one of the signs aswell in bigger symbol above the text also fading in.)
      ),
    );
  }
}
