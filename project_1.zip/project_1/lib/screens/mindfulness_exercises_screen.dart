import 'package:flutter/material.dart';

class MindfulnessExercisesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mindfulness Exercises'),
      ),
      body: Center(
        child: Text('List of Mindfulness Exercises will be displayed here'),
      ),
    );
  }
}
// randomly generated exercises with images, maybe a search bar item to help too find what you are looking for.