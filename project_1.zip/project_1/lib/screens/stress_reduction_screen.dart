import 'package:flutter/material.dart';

class StressReductionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Stress Reduction Techniques'),
      ),
      body: Center(
        child: Text('List of Stress Reduction Techniques will be displayed here'),
      ),
    );
  }
}

// idk, footage of dogs, stock image  no watermark stuff, rain lofi, idk