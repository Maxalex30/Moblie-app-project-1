import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Center(
        child: Text('Settings options will be displayed here'),
      ),
    );
  }
}
// font sizes (adjustments, really look up some basic stuff ain other apps and recomdations form online. defintly voulme control in the app, maybe an option to plug in your own msuic)