import 'package:flutter/material.dart';

class AppProvider with ChangeNotifier {
  // Add your state management logic here
  // For example, managing mindfulness exercises, mood data, etc.
}
